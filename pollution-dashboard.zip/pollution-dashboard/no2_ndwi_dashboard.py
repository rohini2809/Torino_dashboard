import streamlit as st
import rasterio
import numpy as np
import matplotlib.pyplot as plt

st.set_page_config(layout="wide")
st.title("🌍 Milan Pollution & Water Index Dashboard")

# Load raster data
@st.cache_data
def load_raster(path):
    with rasterio.open(path) as src:
        img = src.read(1)
        img = np.where(img == src.nodata, np.nan, img)
    return img

no2 = load_raster("NO2_Milan_2019_2023.tif")
ndwi = load_raster("NDWI_Milan_2023.tif")

# Layout: side-by-side maps
col1, col2 = st.columns(2)

with col1:
    st.subheader("🟠 NO₂ Concentration")
    fig1, ax1 = plt.subplots()
    im1 = ax1.imshow(no2, cmap="YlOrRd", vmin=0, vmax=np.nanpercentile(no2, 95))
    fig1.colorbar(im1, ax=ax1, shrink=0.7, label="NO₂")
    ax1.set_title("NO₂ Levels over Milan")
    ax1.axis('off')
    st.pyplot(fig1)

with col2:
    st.subheader("💧 NDWI (Water Index)")
    fig2, ax2 = plt.subplots()
    im2 = ax2.imshow(ndwi, cmap="Blues", vmin=0, vmax=1)
    fig2.colorbar(im2, ax=ax2, shrink=0.7, label="NDWI")
    ax2.set_title("NDWI over Milan")
    ax2.axis('off')
    st.pyplot(fig2)

# Optional: Overlay logic (advanced)
# Could blend NDWI and NO2 using alpha masks for future enhancements
