import streamlit as st
import geopandas as gpd
import folium
from streamlit_folium import st_folium
import rasterio
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from folium.raster_layers import ImageOverlay
from folium import Choropleth
from PIL import Image
import os
import io
import seaborn as sns
from rasterstats import zonal_stats
import tempfile

# ── Page setup ─────────────────────────────────────────────────────────────
st.set_page_config(layout="wide")
st.title("🌍 Air Pollution in Turin - SDG Dashboard")
st.markdown(
    "Satellite-based visualization of key pollutants in **Turin**, Italy.  \n"
    "Aligned with **SDG 3 (Health)**, **SDG 11 (Sustainable Cities)** & **SDG 13 (Climate Action)**."
)

# ── File mappings ────────────────────────────────────────────────────────────
DATA_DIR = "Torino"
GEOJSON = "torino_only.geojson"

FILE_MAP = {
    "NO2": "no2_turin_clipped.tif",
    "SO2": "so2_turin_clipped.tif",
    "CH4": "ch4_turin_clipped.tif",
    "O3":  "o3_turin_clipped.tif",
    "HCHO":"hcho_turin_clipped.tif"
}

pollutant = st.sidebar.selectbox("Select pollutant:", list(FILE_MAP.keys()))
tif_path   = os.path.join(DATA_DIR, FILE_MAP[pollutant])

# Date range slider for mock user interaction (for later time-enabled TIFFs)
st.sidebar.markdown("### 🗓️ Date Range (mock)")
st.sidebar.slider("Select Date Range", 2019, 2025, (2020, 2024))

# ── Load boundary GeoJSON ───────────────────────────────────────────────────
regions = gpd.read_file(GEOJSON)
if regions.crs is None:
    regions.set_crs(epsg=4326, inplace=True)
center = regions.geometry.centroid.iloc[0].coords[0][::-1]

# ── Create Folium map ───────────────────────────────────────────────────────
m = folium.Map(location=center, zoom_start=11, tiles="CartoDB positron")

# 1) Boundary outline
folium.GeoJson(
    regions,
    name="Municipalities",
    style_function=lambda f: {"color": "black", "weight": 1, "fillOpacity": 0}
).add_to(m)

# 2) Pixel-level heatmap overlay
with rasterio.open(tif_path) as src:
    arr = src.read(1)
    arr[arr == src.nodata] = np.nan
    bnd = src.bounds

    vmin, vmax = np.nanmin(arr), np.nanmax(arr)
    meanv = np.nanmean(arr)
    st.sidebar.markdown("### 📊 Raster Statistics")
    st.sidebar.write(f"Min: {vmin:.6f}")
    st.sidebar.write(f"Max: {vmax:.6f}")
    st.sidebar.write(f"Mean:{meanv:.6f}")

    # normalize
    norm = (arr - vmin) / (vmax - vmin)
    norm = np.nan_to_num(norm)

    # build RGB image via matplotlib colormap
    cmap = cm.get_cmap("plasma")
    rgba = (cmap(norm)[:, :, :3] * 255).astype(np.uint8)
    img = Image.fromarray(rgba)

    # save to temp PNG
    t = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
    img.save(t.name)
    ImageOverlay(
        image=t.name,
        bounds=[[bnd.bottom, bnd.left], [bnd.top, bnd.right]],
        opacity=0.6,
        name="Pixel Heatmap"
    ).add_to(m)

# 3) Region-based choropleth (mean per municipality)
stats = zonal_stats(
    regions,
    tif_path,
    stats=["mean"],
    geojson_out=True,
    nodata=src.nodata
)
regions_stats = gpd.GeoDataFrame.from_features(stats)
regions_stats.set_crs(epsg=4326, inplace=True)

# ✅ Use the correct column (usually "name")
if "name" not in regions_stats.columns:
    st.error("❌ ERROR: The GeoJSON does not contain a 'name' column.")
else:
    Choropleth(
        geo_data=regions_stats,
        data=regions_stats,
        columns=["name", "mean"],
        key_on="feature.properties.name",
        fill_color="YlOrRd",
        fill_opacity=0.5,
        line_opacity=0.2,
        legend_name=f"{pollutant} Mean by Municipality"
    ).add_to(m)

folium.LayerControl().add_to(m)
st.markdown("### 🗺️ Interactive Map")
st_folium(m, width=1200, height=600)

# ── Data Visuals ─────────────────────────────────────────────────────
st.markdown("## 📊 Data Exploration")

# Mini numerical heatmap
st.markdown("#### 🔢 Pixel Grid Heatmap (Preview)")
fig1, ax1 = plt.subplots(figsize=(6, 5))
sns.heatmap(norm[::10, ::10], cmap="plasma", cbar=True, ax=ax1)
st.pyplot(fig1)

# Histogram
st.markdown("#### 📈 Pollution Value Distribution")
fig2, ax2 = plt.subplots(figsize=(6, 3))
vals = norm.flatten()
vals = vals[vals > 0]
ax2.hist(vals, bins=30, color="orange", edgecolor="black")
ax2.set_xlabel("Normalized Value")
ax2.set_ylabel("Pixel Count")
st.pyplot(fig2)

# Municipality table
st.markdown("#### 🏙️ Municipality Pollution Ranking")
df_table = regions_stats[["name", "mean"]].sort_values(by="mean", ascending=False)
st.dataframe(df_table.rename(columns={"name": "Municipality", "mean": f"{pollutant} Level"}))

# ── SDG Cards ───────────────────────────────────────────────────────────
st.markdown("## 🌱 SDG Relevance")
c1, c2, c3 = st.columns(3)
c1.success("🧍 **SDG 3: Good Health**\nAir quality impacts respiratory & cardiovascular health.")
c2.info("🏙️ **SDG 11: Sustainable Cities**\nData-driven planning reduces urban pollution hotspots.")
c3.warning("🌍 **SDG 13: Climate Action**\nMonitoring supports emissions reduction & climate resilience.")