from flask import Flask, render_template
import pandas as pd
import plotly.graph_objs as go
import plotly.io as pio

app = Flask(__name__)

@app.route("/")
def index():
    df = pd.read_csv("NO2_TimeSeries_Milan.csv")
    df['date'] = pd.to_datetime(df['date'])
    
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df['date'], y=df['mean'], mode='lines+markers', name='NO₂'))
    fig.update_layout(title="NO₂ in Milan (2019–2023)",
                      xaxis_title="Date", yaxis_title="NO₂ Density")
    
    graph_html = pio.to_html(fig, full_html=False)
    return render_template("index.html", graph_html=graph_html)

if __name__ == "__main__":
    app.run(debug=True)
